#
# Valet-Key for Azure Table
#
# Version 1.1
#
# Output : Shared Access Token for all tables
# 
# Extracting information from application settings App Service
#
#
$startdate = Get-Date
$ExpirityPeriod = $Env:AuthorizationModuleExpirationPeriod # Durée de vie du token
$StorageAccountName = $env:AuthorizationModuleStorageAccountName
$AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
$KeyVaultName = $env:AuthorizationModuleKeyVault
$AuthorisationModuleStorageAccountMasterKey = $env:AuthorizationModuleStorageAccountMasterKey
#$key = $env:AuthorizationModuleStorageAccountMasterKey # To Be removed
#
"Initialization  $([math]::round((New-TimeSpan -Start $startdate -End (get-date)).TotalSeconds,2)) TotalSeconds"
#
# Generate token
#
$endpoint = $env:MSI_ENDPOINT
$secret = $env:MSI_SECRET
$message = "Generating Access token to access Key Vault."
$Message
Try
{
    $URL = "https://management.azure.com/"
    $vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'
    $header = @{'Secret' = $secret}
    $authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint +'?resource=' +$vaultTokenURI)
    $Message = "Managed Identity Service for Azure Function generated a token."
    $Message
    #
    # Accessing the Primary Key Storage Account in Key Vault
    #
    Try
    {
        $vaultSecretURI = "https://" + $KeyVaultName + ".vault.azure.net/secrets/"+ $AuthorisationModuleStorageAccountMasterKey + "?api-version=2015-06-01"
        $Message = "Extracting Storage Account Primary Key from KeyVault $vaultSecretURI."
        $Message
        $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)"}
        $VaultURL = Invoke-RestMethod -Method GET -Uri $vaultSecretURI -ContentType 'application/json' -Headers $requestHeader
        $message = "Storage Account Primary Key for $KeyVaultName extracted successfully."
        $message
        If (($VaultURL.value) -ne $null)
        {
            Try
            {
                #
                # Constructing a Storage Account Key with Primary key
                # 
                $key = "/2Y9HAPfItuM4lOWVVRs3ruEGG56e64imFqMJbAFBLFdD9K1/w5egbJkvYAcDPxVAOrN1FyKWeQo/aZcoIM44A==" 
                $StorageContext = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $($VaultURL.value)    
                [DateTime]$ExpirityTime = (Get-Date).AddMinutes($ExpirityPeriod )
                 $sastoken = New-AzureStorageAccountSASToken -Service Table -ResourceType Service,Container,Object -Permission "rl" -Context $StorageContext  -Protocol HttpsOnly -ExpiryTime $ExpirityTime   
                [System.IO.File]::WriteAllText($res,$sastoken) 
                "Generated  $([math]::round((New-TimeSpan -Start $startdate -End (get-date)).TotalSeconds,2)) TotalSeconds"
            }
            Catch
            {
                #  Write-Error "INTERNAL ERROR"
                Out-File -Encoding Ascii -FilePath $res -inputObject "INTERNALERROR"
            }       
        }
        Else
        {
            #
            # Invalid Primary Key
            #
            Out-File -Encoding Ascii -FilePath $res -inputObject "INVALIDSTORAGEACCOUNTPRIMARYKEY"
        }
    }
    Catch
    {
        Out-File -Encoding Ascii -FilePath $res -inputObject "KEYVAULTACCESSERROR"
        $message = $_.Exception.Message
        $message        
    }

}
Catch
{
    Out-File -Encoding Ascii -FilePath $res -inputObject "MANAGERSERVICEIDENTITYERROR"
    $message = $_.Exception.Message
    $message
}


