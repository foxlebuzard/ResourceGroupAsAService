# Pour une souscription Azure donnée
#
# Version 1.0
#
#
# POST method: $req
$Message = "Initializing Get-AuthorizedRegions API call `r`n"
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$SubscriptionID = $requestBody.SubscriptionID
$KeyValetUrl = $env:AuthorizationModuleReadKeyvaletURL
$result = Get-Variable -name REQ_HEADERS_X-MS-CLIENT-PRINCIPAL-NAME -ErrorAction SilentlyContinue
if ($result.name -ne $null) 
{
    #
    # Check subscriptionID Format
    #
    If ($SubscriptionID -match("^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$") -eq $True)
    {
        #
        # User Authentication accepted by Active Directory
        #
        $Token = Invoke-RestMethod -Uri $KeyValetUrl -Method POST -ContentType 'application/json'  
        If ($Token -ne $Null)
        {
            #
            # Create security context to Access Azure storage table
            #
            $Message = $Message + "Got Key from Valet-Get. `r`n" 
            $storageAccountName = $env:AuthorizationModuleStorageAccountName
            $AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
            $context = New-AzureStorageContext -StorageAccountName $storageAccountName -SasToken $Token
            $AuthorizedCallerTable = Get-AzureStorageTable -Name $AuthorizedCallerTableName -Context $context    
            #
            # Filter for subscriptionID & User
            #
            [string]$filter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal, $SubscriptionID)
            [string]$filter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("RowKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,($($result.value)).tolower())
            [string]$finalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($filter1,"and",$filter2)
            $searchsubscription = Get-AzureStorageTableRowByCustomFilter -table $AuthorizedCallerTable -customFilter $finalFilter
            $FoundSubscription = $False
            If ($SearchSubscription -ne $Null)
            {
                $Message = $Message + "Found searched row in AuthorizedCallers table. `r`n"     
                ForEach($subscription in $SearchSubscription)
                {
                    If ($subscription.Authorized -eq $True)
                    {
                        $Message = $Message + "Subscription is authorized for user $(($result.value).tolower()). `r`n"
                        $FoundSubscription = $True
                    }
                }
            }
            If ($FoundSubscription -eq $True)
            {
                If (($subscription.AuthorizedRegions) -ne $Null)
                {
                    $json = ($subscription.AuthorizedRegions) |ConvertTo-Json
                    Out-File -Encoding Ascii -FilePath $res -inputObject $json -NoNewline
                }
                Else
                {
                    Out-File -Encoding Ascii -FilePath $res -inputObject "NONE" -NoNewline
                }
            }
            Else
            {
                $Message = $Message + "Subscription $SubscriptionID is not Authorized for user $(($result.value).tolower()) . `r`n" 
                Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
            }
        }
        Else
        {
            $Message = $Message + "Unable to get token from Valet-Key. `r`n"
            Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline 
        }
    }
    Else
    {
        $Message = $Message + "Invalid SubscriptionID. `r`n" 
        Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
    }
}
else
{
    $Message = $Message + "Unauthenticated Access. `r`n" 
    Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
}