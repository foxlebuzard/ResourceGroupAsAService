# Pour une souscription Azure donnée
#
# Version 1.0
#
#
# POST method: $req
$Message = "Initializing Get-AuthorizedCostCenters API call `r`n"
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$SubscriptionID = $requestBody.SubscriptionID
$KeyValetUrl = $env:AuthorizationModuleReadKeyvaletURL

# A intégrer comme fonction de trace

#Add-Type -Path "Microsoft.ApplicationInsights.dll"
$TelemetryClient = New-Object Microsoft.ApplicationInsights.TelemetryClient
$TelemetryClient.InstrumentationKey = $env:ApplicationInsightInstrumentationKey
$TelemetryClient.TrackTrace("Initializing Get-AuthorizedCostCenters API call")
$result = Get-Variable -name REQ_HEADERS_X-MS-CLIENT-PRINCIPAL-NAME -ErrorAction SilentlyContinue
if ($result.name -ne $null) 
{
    #
    # Check subscriptionID Format
    #
    If ($SubscriptionID -match("^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$") -eq $True)
    {
        #
        # User Authentication accepted by Active Directory
        #
        $Token = Invoke-RestMethod -Uri $KeyValetUrl -Method POST -ContentType 'application/json'  
        If ($Token -ne $Null)
        {
            #
            # Create security context to Access Azure storage table
            #
            $Message = $Message + "Got Key from Valet-Get. `r`n" 
            $TelemetryClient.TrackTrace("Got Key from Valet-Get.")
            $storageAccountName = $env:AuthorizationModuleStorageAccountName
            $AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
            $context = New-AzureStorageContext -StorageAccountName $storageAccountName -SasToken $Token
            $AuthorizedCallerTable = Get-AzureStorageTable -Name $AuthorizedCallerTableName -Context $context    
            #
            # Filter for subscriptionID & User
            #
            [string]$filter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal, $SubscriptionID)
            [string]$filter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("RowKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,($($result.value)).tolower())
            [string]$finalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($filter1,"and",$filter2)
            $searchsubscription = Get-AzureStorageTableRowByCustomFilter -table $AuthorizedCallerTable -customFilter $finalFilter
            $FoundSubscription = $False
            If ($SearchSubscription -ne $Null)
            {
                $Message = $Message + "Found searched row in AuthorizedCallers table. `r`n"     
                $TelemetryClient.TrackTrace("Found searched row in AuthorizedCallers table.")
                ForEach($subscription in $SearchSubscription)
                {
                    If ($subscription.Authorized -eq $True)
                    {
                        $Message = $Message + "Subscription is authorized for user $(($result.value).tolower()). `r`n"
                        $TelemetryClient.TrackTrace("Subscription is authorized for user $(($result.value).tolower())")
                        $FoundSubscription = $True
                    }
                }
            }
            If ($FoundSubscription -eq $True)
            {
                If (($subscription.AuthorizedCostCenters) -ne $Null)
                {
                    $json = ($subscription.AuthorizedCostCenters) |ConvertTo-Json
                    Out-File -Encoding Ascii -FilePath $res -inputObject $json -NoNewline
                }
                Else
                {
                    Out-File -Encoding Ascii -FilePath $res -inputObject "NONE" -NoNewline
                }
            }
            Else
            {
                $Message = $Message + "Subscription $SubscriptionID is not Authorized for user $(($result.value).tolower()) . `r`n" 
                $TelemetryClient.TrackTrace("Subscription $SubscriptionID is not Authorized for user $(($result.value).tolower())")
                Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
            }
        }
        Else
        {
            $Message = $Message + "Unable to get token from Valet-Key. `r`n"
            $TelemetryClient.TrackTrace("Unable to get token from Valet-Key.")
            Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline 
        }
    }
    Else
    {
        $Message = $Message + "Invalid SubscriptionID. `r`n" 
        $TelemetryClient.TrackTrace("Invalid SubscriptionID.")
        Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
    }
}
else
{
    $Message = $Message + "Unauthenticated Access. `r`n" 
    $TelemetryClient.TrackTrace("Unauthenticated Access.")
    Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
}