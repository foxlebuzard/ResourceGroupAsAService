#
# Version 1.0
#
# POST method: $req
$Trace = ""
$Message = "Initializing Get-AuthorizedSubscriptions API call `r`n"
$Trace += $Message
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$KeyValetUrl = $env:AuthorizationModuleReadKeyvaletURL
$result = Get-Variable -name REQ_HEADERS_X-MS-CLIENT-PRINCIPAL-NAME -ErrorAction SilentlyContinue
if ($result.name -ne $null) 
{
    #
    # User Authentication accepted by Active Directory
    #
    $Token = Invoke-RestMethod -Uri $KeyValetUrl -Method POST -ContentType 'application/json'  
    If ($Token -ne $Null)
    {
        #
        # Create security context to Access Azure storage table
        #
        $Message + "Got Key from Valet-Key. `r`n"
        $Trace += $Message
        $storageAccountName = $env:AuthorizationModuleStorageAccountName
        $AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
        $context = New-AzureStorageContext -StorageAccountName $storageAccountName -SasToken $Token
        $AuthorizedCallerTable = Get-AzureStorageTable -Name $AuthorizedCallerTableName -Context $context
        #
        # Améliorer le filtre pour intégrer le filtrage Authorized
        #
        $searchsubscription = Get-AzureStorageTableRowByColumnName -table $AuthorizedCallerTable -columnName "RowKey" -value ($($result.value)).tolower() -operator Equal
        $subscriptionlist = New-Object System.Collections.Generic.List[System.Object]
        If ($SearchSubscription -ne $Null)
        {
            $Message + "Found one or more rows in AuthorizedCallers table. `r`n"
            $Trace += $Message
            #
            # One or more subscription are registrer in the AuthorizedCallers table
            #       
            ForEach($subscription in $SearchSubscription)
            {
                #
                # Parsing rows with Authorized flag enabled
                #
                If ($subscription.Authorized -eq $True)
                {
                    #
                    # Building subscriptionlist
                    #
                    $subscriptionlist.Add($subscription.PartitionKey)
                }
            }
        }
        If ($subscriptionlist.count -GT 0)
        {
            $Message = "$($subscriptionlist.count) subscriptions allowed to $(($($result.value)).tolower()). `r`n"
        }
        Else
        {
            $Message = "No subscription allowed to $(($($result.value)).tolower()). `r`n"
        }
        $Trace += $Message
        $json = $subscriptionlist |ConvertTo-Json
        Out-File -Encoding Ascii -FilePath $res -inputObject $json
    }
    Else
    {
        $Message = "Unable to get token from Valet-Key. `r`n"
        $Trace += $Message
    }
}
else
{   $Message = "Unauthenticated."
    $Trace += $Message
    Out-File -Encoding Ascii -FilePath $res -inputObject $Message
}