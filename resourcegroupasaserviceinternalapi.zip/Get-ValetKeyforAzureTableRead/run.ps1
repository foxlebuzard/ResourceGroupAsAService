#
# Valet-Key for Azure Table
#
# Version 1.1
#
# Output : Shared Access Token for all tables
# 
#
$startdate = Get-Date
$ExpirityPeriod = $Env:AuthorizationModuleExpirationPeriod # Durée de vie du token
$StorageAccountName = $env:AuthorizationModuleStorageAccountName
$AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
$KeyVaultName = $env:AuthorizationModuleKeyVault
$AuthorisationModuleStorageAccountMasterKey = $env:AuthorizationModuleStorageAccountMasterKey
$message = "ValetKeyForAzure Table API - Initialization  $([math]::round((New-TimeSpan -Start $startdate -End (get-date)).TotalSeconds,2)) TotalSeconds"
$message
#
# Generate token
#
$endpoint = $env:MSI_ENDPOINT
$secret = $env:MSI_SECRET
$message = "ValetKeyForAzure Table API - Generating Access token to access Key Vault."
$message
Try
{
    $URL = "https://management.azure.com/"
    $vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'
    $header = @{'Secret' = $secret}
    $authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint +'?resource=' +$vaultTokenURI)
    $Message = "ValetKeyForAzure Table API - Managed Identity Service for Azure Function generated a token."
    $message
    #
    # Accessing the Primary Key Storage Account in Key Vault
    #
    Try
    {
        $vaultSecretURI = "https://" + $KeyVaultName + ".vault.azure.net/secrets/"+ $AuthorisationModuleStorageAccountMasterKey + "?api-version=2015-06-01"
        $Message = "ValetKeyForAzure Table API - Extracting Storage Account Primary Key from KeyVault $vaultSecretURI."
        $message
        $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)"}
        $VaultURL = Invoke-RestMethod -Method GET -Uri $vaultSecretURI -ContentType 'application/json' -Headers $requestHeader
        $message = "ValetKeyForAzure Table API - Storage Account Primary Key for $KeyVaultName extracted successfully."
        $message
        If (($VaultURL.value) -ne $null)
        {
            Try
            {
                #
                # Constructing a Storage Account Key with Primary key
                # 
                $StorageContext = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $($VaultURL.value)    
                [DateTime]$ExpirityTime = (Get-Date).AddMinutes($ExpirityPeriod )
                 $sastoken = New-AzureStorageAccountSASToken -Service Table -ResourceType Service,Container,Object -Permission "rl" -Context $StorageContext  -Protocol HttpsOnly -ExpiryTime $ExpirityTime   
                [System.IO.File]::WriteAllText($res,$sastoken) 
                $message = "ValetKeyForAzure Table API - Generated  $([math]::round((New-TimeSpan -Start $startdate -End (get-date)).TotalSeconds,2)) TotalSeconds"
                $message
            }
            Catch
            {
                #  Write-Error "INTERNAL ERROR"
                Out-File -Encoding Ascii -FilePath $res -inputObject "INTERNALERROR"
                $message = "ValetKeyForAzure Table API - Internal Error."
                $message
            }       
        }
        Else
        {
            #
            # Invalid Primary Key
            #
            Out-File -Encoding Ascii -FilePath $res -inputObject "INVALIDSTORAGEACCOUNTPRIMARYKEY"
            $message = "ValetKeyForAzure Table API -Invalid primary Key for Storage Account."
            $message
        }
    }
    Catch
    {
        Out-File -Encoding Ascii -FilePath $res -inputObject "KEYVAULTACCESSERROR"        
        $message = "ValetKeyForAzure Table API - KEYVAULTACCESSERROR $_.Exception.Message"
        $message
    }
}
Catch
{
    Out-File -Encoding Ascii -FilePath $res -inputObject "MANAGERSERVICEIDENTITYERROR"
    $message = $_.Exception.Message
    $message = "ValetKeyForAzure Table API - MANAGERSERVICEIDENTITYERROR $_.Exception.Message"
    $message
}