#
# Version 1.0
#
#
# POST method: $req
$Message = "Initializing Get-AuthorizedEnvironments API call `r`n"
$Message
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$SubscriptionID = $requestBody.SubscriptionID
$KeyValetUrl = $env:AuthorizationModuleReadKeyvaletURL
$result = Get-Variable -name REQ_HEADERS_X-MS-CLIENT-PRINCIPAL-NAME -ErrorAction SilentlyContinue
if ($result.name -ne $null) 
{
    #
    # Check subscriptionID Format
    #
    If ($SubscriptionID -match("^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$") -eq $True)
    {
        #
        # User Authentication accepted by Active Directory
        #
        $Token = Invoke-RestMethod -Uri $KeyValetUrl -Method POST -ContentType 'application/json'  
        If ($Token -ne $Null)
        {
            #
            # Create security context to Access Azure storage table
            #
            $Message = "Got Key from Valet-Get."
            $Message 
            $storageAccountName = $env:AuthorizationModuleStorageAccountName
            $AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
            $context = New-AzureStorageContext -StorageAccountName $storageAccountName -SasToken $Token
            $AuthorizedCallerTable = Get-AzureStorageTable -Name $AuthorizedCallerTableName -Context $context       
            #
            # Filter for subscriptionID & User
            #
            [string]$filter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal, $SubscriptionID)
            [string]$filter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("RowKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,($($result.value)).tolower())
            [string]$finalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($filter1,"and",$filter2)
            $searchsubscription = Get-AzureStorageTableRowByCustomFilter -table $AuthorizedCallerTable -customFilter $finalFilter
            $Environmentlists = New-Object System.Collections.Generic.List[System.Object]
            If ($SearchSubscription -ne $Null)
            {
                $Message = "Found one or more rows in AuthorizedCallers table."
                $Message 
                #
                # One or more subscription are registrer in the AuthorizedCallers table
                #       
                ForEach($subscription in $SearchSubscription)
                {
                    #
                    # Parsing rows with Authorized flag enabled
                    #
                    If ($subscription.Authorized -eq $True)
                    {
                        #
                        # Building subscriptionlist
                        #
                        $Environmentlists.Add($subscription.Authorizedenvironments)
                    }
                }
            }
            If ($Environmentlists.count -GT 0)
            {
                $Message = "$($Environmentlists.count) subscriptions allowed to $(($($result.value)).tolower())."
            }
            Else
            {
                $Message =  "No subscription allowed to $(($($result.value)).tolower())."
            }
            $message
            $json = $Environmentlists |ConvertTo-Json
            Out-File -Encoding Ascii -FilePath $res -inputObject $json
        }
        Else
        {
            $Message = "Unable to get token from Valet-Key."
            $message 
        }
    }
    Else
    {
        $Message = "Invalid subscriptionID."
        $message
    }
}
else
{
    Out-File -Encoding Ascii -FilePath $res -inputObject "Unauthenticated."
}