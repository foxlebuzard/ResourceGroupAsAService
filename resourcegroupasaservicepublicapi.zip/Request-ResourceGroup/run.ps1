# POST method: $req
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$SubscriptionID = $requestBody.SubscriptionID
$DisplayNameTag = $env:AuthorizationModuleDisplayName
$EnvironnementTagname = $Env:AuthorizationModuleEnvironnementTagname
$CostCenterTagname = $Env:AuthorizationModuleCostCenterTagName
$ProjectnameTagname = $Env:AuthorizationModuleProjectTagName
$OwnerTagname = $Env:AuthorizationModuleOwnerTagName
$CreatedOnTagName = $Env:AuthorizationModuleCreatedOnTagName
$BackupTagName = $env:AuthorizationModuleBackupTagName
$SLATagName = $env:AuthorizationModuleSLAName
$KeyVaultName = $env:AuthorizationModuleKeyVault
$KeyVaultSubscriptionLogin = $env:AuthorizationModuleKeyVaultSubscriptionLogin
$KeyVaultSubscriptionPassword = $env:AuthorizationModuleKeyVaultSubscriptionPassword
$result = Get-Variable -name REQ_HEADERS_X-MS-CLIENT-PRINCIPAL-NAME -ErrorAction SilentlyContinue
If ($result.Value -ne $null) 
{
    #
    # User is Authenticated with Azure AD
    #  
    If ($RequestBody.ResourceGroupname -Ne $Null)
    {
        #
        # Resource group name parameter is not empty.
        #
        $ResourceGroupName = $requestBody.ResourceGroupname
        #
        # Check if region parameter is not empty
        #
        If ($RequestBody.Region -ne $null)
        {
            $selectedRegion = $RequestBody.Region        
            #
            # Check SubscriptionID Parameter
            #
            If ($SubscriptionID -match("^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$") -eq $True)
            {
                $Account = ($result.Value).tolower()
                If ($RequestBody.Environment -ne $null)
                {
                    $AuthorizedEnvironment = ($RequestBody.Environment).ToLower()
                }
                Else
                {
                    $AuthorizedEnvironment = $Null
                }
                #
                # Check Costcenter parameter
                #
                If ($RequestBody.CostCenter -ne $null)
                {
                    $AuthorizedCostCenter = ($RequestBody.CostCenter).ToLower()
                }
                Else
                {
                    #
                    # No CostCenter, will be using default value from Azure table
                    #
                    $AuthorizedCostCenter = $Null
                }
                #
                # Check Project Name parameter
                #
                If ($RequestBody.ProjectName -ne $Null)
                {
                    $ProjectName = $RequestBody.ProjectName
                }
                Else
                {
                    $ProjectName = $Null
                }
                #
                # Check backuptag
                #
                If ($RequestBody.Backup -ne $null)
                {
                    $BackupPolicy = $RequestBody.Backup
                }
                Else
                {
                    $BackupPolicy = $Null
                }
                #
                # Check SLA Tag
                #
                If ($RequestBody.SLA -Ne $Null)
                {
                    $SLA = $RequestBody.SLA
                }
                Else
                {
                    $SLA = $Null
                }
                #
                # Get Key from Valet-Key
                #
                $KeyValetUrl = $env:AuthorizationModuleReadKeyvaletURL
                $Token = Invoke-RestMethod -Uri $KeyValetUrl -Method POST -ContentType 'application/json'  
                If ($Token -ne $Null)
                {
                    #
                    # Création du contexte de sécurité pour accéder au stockage
                    #
                    $message = "Got Key from Valet-Key."
                    $message
                    $storageAccountName = $env:AuthorizationModuleStorageAccountName
                    $AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
                    $context = New-AzureStorageContext -StorageAccountName $storageAccountName -SasToken $Token
                    $AuthorizedCallerTable = Get-AzureStorageTable -Name $AuthorizedCallerTableName -Context $context
                    [string]$filter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$SubscriptionID)
                    [string]$filter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("RowKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$Account)
                    [string]$finalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($filter1,"and",$filter2)
                    $searchsubscription = Get-AzureStorageTableRowByCustomFilter -table $AuthorizedCallerTable -customFilter $finalFilter
                    If ($SearchSubscription -ne $Null)
                    {
                        $Message = "Subscription ID $SubscriptionID found in authorizedCall table."
                        $message
                        If ($searchsubscription.Authorized -eq $True)
                        {
                            $Message = "User $Account is authorized to use the service on subscription ID $SubscriptionID"
                            $Message
                            #
                            # recherche la liste des Authorized environments pour l'utilisateur
                            #
                            # BUG ne fonctionne pas si empty
                            If ($searchsubscription.AuthorizedEnvironments -ne $null)
                            {
                                $message = "Authorized environment list contains : $($searchsubscription.AuthorizedEnvironments)"
                                $message
                                $EnvironmentSplitTable = $searchsubscription.AuthorizedEnvironments.Split(",")
                                $UserAllowedtoEnvironment = $False
                                ForEach ($environmenttocheck in $EnvironmentSplitTable)
                                {
                                    If (($environmenttocheck).ToLower() -eq $AuthorizedEnvironment)
                                    {
                                        $UserAllowedtoEnvironment = $True
                                        Break
                                    }         
                                }
                                If ($UserAllowedtoEnvironment -eq $True)
                                {
                                    $message = "User $Account is authorized for environement $AuthorizedEnvironment"
                                    $message
                                    #
                                    # Check if user is allowed for requested cost-center
                                    #
                                    If ($AuthorizedCostCenter -eq $null)
                                    {
                                        #
                                        # Check in table DefaultCostCenter if parameter is Null
                                        #
                                        $DefaultCostCenterTableName = $env:AuthorizationModuleDefaultCostCenterTableName
                                        $DefaultCostCenterTable = Get-AzureStorageTable -Name $DefaultCostCenterTableName -Context $context
                                        [string]$CostCenterfilter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$SubscriptionID)
                                        [string]$CostCenterfilter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("RowKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$Account)
                                        [string]$CostCenterfinalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($CostCenterfilter1,"and",$CostCenterfilter2)
                                        $searchDefaultCostCenter = Get-AzureStorageTableRowByCustomFilter -Table $DefaultCostCenterTable -customFilter $CostCenterfinalFilter
                                        If ($searchDefaultCostCenter -ne $Null)
                                        {
                                            #
                                            # Found the Default Cost Center
                                            #
                                            $message = "Default Cost Center found for user $account in subscription $subscriptionID : $($searchDefaultCostCenter.CostCenter)"
                                            $message
                                            $AuthorizedCostCenter = $searchDefaultCostCenter.CostCenter
                                        }
                                    }
                                    If ($AuthorizedCostCenter -ne $null)
                                    {
                                        $CostCenterSplitTable = $searchsubscription.AuthorizedCostCenters.Split(",")
                                        $UserAllowedCostcenter = $False                    
                                        ForEach ($costcentertocheck in $CostCenterSplitTable)
                                        {
                                            If (($costcentertocheck).ToLower() -eq $AuthorizedCostCenter)
                                            {
                                                $costcentertocheck = $True
                                                Break
                                            }
                                        }
                                        If ($costcentertocheck -eq $True)
                                        {
                                            $message = "$Account is authorized to use cost center $AuthorizedCostCenter"
                                            $message                                        
                                            $message = "Accessing KeyVault to get Subscription access secrets."
                                            $Message
                                            #
                                            # Extracting subscription secret from KeyVault
                                            #
                                            $endpoint = $env:MSI_ENDPOINT
                                            $secret = $env:MSI_SECRET
                                            #
                                            # Prepare Authentication with MSI for Azure Key Vault
                                            #  
                                            $message = "Generating Access token to access Key Vault."
                                            $Message
                                            $URL = "https://management.azure.com/"
                                            $vaultTokenURI = 'https://vault.azure.net&api-version=2017-09-01'
                                            $header = @{'Secret' = $secret}
                                    # Améliorer gestion d'erreur
                                            $authenticationResult = Invoke-RestMethod -Method Get -Headers $header -Uri ($endpoint +'?resource=' +$vaultTokenURI)
                                            $authenticationResult
                                            If ($authenticationResult -ne $Null)
                                            {
                                                $message = "Azure Function Sucessfully authenticated against Azure."
                                                $message
                                                Try
                                                {
                                                    #
                                                    # Extracting instance name of the key Vault for the requested subscription
                                                    #
                                                    $Message = "Extracting secrets to access subscription $SubscriptionID From KeyVault https://$KeyVaultName.vault.azure.net/"
                                                    $Message
                                                    $vaultSecretURI = "https://" + $KeyVaultName + ".vault.azure.net/secrets/"+ $SubscriptionID + "?api-version=2015-06-01"
                                                    $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)"}
                                                    $VaultURL = Invoke-RestMethod -Method GET -Uri $vaultSecretURI -ContentType 'application/json' -Headers $requestHeader
                                                    $VaultURL.value
                                                    $message = "Secrets for Subscription $SubscriptionID are stored in Keyvault $($VaultURL.value)."
                                                    $message
                                                    #
                                                    # Extracting the Login from Keyvault related to Azure Subscription
                                                    #
                                                    $message = "Extracting Secrets from Keyvault $($VaultURL.value)."
                                                    $Message
                                                    $KeyVaultSecretURL = $($VaultURL.value) + "secrets/" + $KeyVaultSubscriptionLogin + "?api-version=2015-06-01"
                                                    $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)"}
                                                    $SubscriptionLogin = Invoke-RestMethod -Method GET -Uri $KeyVaultSecretURL -ContentType 'application/json' -Headers $requestHeader
                                                    #
                                                    # Extracting Password from KeyVault Related to Azure Subscription
                                                    #
                                                    $KeyVaultSecretURL = $($VaultURL.value) + "secrets/" + $KeyVaultSubscriptionPassword + "?api-version=2015-06-01"
                                                    $requestHeader = @{ Authorization = "Bearer $($authenticationResult.access_token)"}
                                                    $SubscriptionPassword = Invoke-RestMethod -Method GET -Uri $KeyVaultSecretURL -ContentType 'application/json' -Headers $requestHeader
                                                    $message = "Extracting Secrets from Keyvault $($VaultURL.value) completed."
                                                    $Message
                                                    If ($SubscriptionLogin.Value -ne $Null -and $SubscriptionPassword.Value -Ne $Null)
                                                    {
                                                        $Message = "Got credentials to Access subscription $SubscriptionID."
                                                        $Message
                                                        $Password = ConvertTo-SecureString -String $($SubscriptionPassword.Value) -AsPlainText -Force
                                                        $Credential = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $($SubscriptionLogin.Value), $Password
                                                        Try
                                                        {
                                                            $login = Login-AzureRmAccount -Credential $credential -SubscriptionID $SubscriptionID
                                                            If($login -ne $null)
                                                            {
                                                                $message = "Successfull login to Azure subscription $SubscriptionID with Azure Function Managed Identity."
                                                                $message
                                                                #
                                                                # Check is resource group already exists
                                                                #
                                                                $CheckRG = Get-AzureRMResourceGroup -ResourceGroupname $ResourceGroupName -ErrorAction SilentlyContinue
                                                                If ($CheckRG -eq $Null)
                                                                {
                                                                    #
                                                                    # Requested resource group does not exists
                                                                    #
                                                                    $message = "Requested resource Group $ResourceGroupName does not exists in subscription $SubscriptionID."
                                                                    $message
                                                                    #
                                                                    # Check if Selectedregion is an allowed region
                                                                    #                                        
                                                                    If (($searchsubscription.AuthorizedRegions) -ne $null)
                                                                    {
                                                                        $RegionsSplitTable = $searchsubscription.AuthorizedRegions.Split(",")
                                                                        $UserAllowedRegion = $False                    
                                                                        ForEach ($AzureRegion in $RegionsSplitTable)
                                                                        {
                                                                            If ($AzureRegion -match $selectedRegion)
                                                                            {
                                                                                $UserAllowedRegion = $True
                                                                                Break
                                                                            }          
                                                                        }
                                                                        If ($UserAllowedRegion -eq $True)
                                                                        { 
                                                                            $message = "$selectedRegion is allowed for user $account in subscription $SubscriptionID."
                                                                            $message 
                                                                            #
                                                                            # Check is selected region is available for subscription
                                                                            #
                                                                            $regionExists = Get-AzureRmLocation | where {$_.location -match $selectedRegion}
                                                                            If ($regionExists -ne $null)
                                                                            {
                                                                                $Message = "Azure region $selectedRegion is available in subscription $SubscriptionID."
                                                                                $Message
                                                                                #
                                                                                # Create Resource Group
                                                                                #           
                                                                                Try
                                                                                {
                                                                                    $message = "Creating resource group $ResourceGroupName in Azure Region $selectedRegion."
                                                                                    $message 
                                                                                    $newrg = New-AzureRmResourceGroup -Name $ResourceGroupName -Location $selectedRegion -Tag @{Name=$EnvironnementTagname;Value=$AuthorizedEnvironment}, @{Name=$OwnerTagname; Value=$Account}, @{Name=$DisplayNameTag;Value=$ResourceGroupName}, @{Name=$CostCenterTagname; Value=$AuthorizedCostCenter}, @{Name=$CreatedOnTagName;Value=$((get-date).ToString("dd/MM/yyyy"))}
                                                                                    If ($newrg -ne $Null)
                                                                                    {
                                                                                        #
                                                                                        # Adding optional Tags
                                                                                        #
                                                                                        $message = "Processing non mandatory tags for Resource Group $ResourceGroupName"
                                                                                        $Message
                                                                                        $NewTags = (Get-AzureRmResourceGroup -Name $ResourceGroupName).Tags
                                                                                        $NewTags
                                                                                        If ($BackupPolicy -ne $null)
                                                                                        {
                                                                                            $NewTags += @{Name=$BackupTagName; Value=$BackupPolicy}
                                                                                        }
                                                                                        If ($ProjectName -ne $Null)
                                                                                        {
                                                                                            $NewTags += @{Name=$ProjectnameTagname; Value=$ProjectName}
                                                                                        }
                                                                                        If ($SLA -Ne $Null)
                                                                                        {
                                                                                            $NewTags += @{Name=$SLATagName; Value=$SLA}
                                                                                        }
                                                                                        Set-AzureRMResourceGroup -Name $ResourceGroupName -Tag $NewTags
                                                                                        $message = "Non mandatory tags for Resource Group $ResourceGroupName processed successfully."
                                                                                        $Message
                                                                                        #
                                                                                        # Processing Roles from AuthorizedIAMTemplateRole table
                                                                                        #
                                                                                        $IAMTemplateRoleTableName = $env:AuthorizationModuleIAMTemplateRoleTableName
                                                                                        $IAMTemplateRoleTable = Get-AzureStorageTable -Name $IAMTemplateRoleTableName -Context $context
                                                                                        [string]$IAMfilter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$SubscriptionID)
                                                                                        [string]$IAMfilter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("Environment",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$AuthorizedEnvironment.toupper())
                                                                                        [string]$IAMfinalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($IAMfilter1,"and",$IAMfilter2)
                                                                                        $searchIAMTemplate = Get-AzureStorageTableRowByCustomFilter -Table $IAMTemplateRoleTable -customFilter $IAMfinalFilter
                                                                                        If ($searchIAMTemplate.count -ne 0)
                                                                                        {
                                                                                            $message ="$($searchIAMTemplate.Count) Role assignment to apply to newlycreated resource group."
                                                                                            $message
                                                                                            ForEach ($IAMTemplate in $searchIAMTemplate)
                                                                                            {
                                                                                                #
                                                                                                # Parse each IAM template
                                                                                                #
                                                                                                $Message = "Processing role assignment $IAMTemplate."
                                                                                                $Message
                                                                                                If ($IAMTemplate.AzureADGroup -ne $null)
                                                                                                {
                                                                                                    #
                                                                                                    # Check Azure AD Group if exists
                                                                                                    #
                                                                                                    $ObjectID = Get-AzureRMADGroup -SearchString $($IAMTemplate.AzureADGroup)
                                                                                                    If ($ObjectID -ne $Null)
                                                                                                    {
                                                                                                        $Message = "Azure AD Group $($IAMTemplate.AzureADGroup) resolved."
                                                                                                        $message
                                                                                                        #
                                                                                                        # Check if role Exists
                                                                                                        #
                                                                                                        If ($IAMTemplate.Role -ne $Null)
                                                                                                        {
                                                                                                            $CheckRole = Get-AzureRmRoleDefinition -Name $IAMTemplate.Role
                                                                                                            If ($CheckRole -ne $null)
                                                                                                            {
                                                                                                                $message = "$($IAMTemplate.Role) role exists in subscription $subscriptionID."
                                                                                                                $Message
                                                                                                                #
                                                                                                                # Perform Role Assignment on newly created resource group
                                                                                                                #
                                                                                                                Try
                                                                                                                {
                                                                                                                    $Message = "Performing Role Assignment for role $($IAMTemplate.Role)"
                                                                                                                    $Message
                                                                                                                    New-AzureRMRoleAssignment -ObjectId $ObjectID.ID -RoleDefinitionName $($IAMTemplate.Role) -ResourceGroupName $ResourceGroupName
                                                                                                                }
                                                                                                                catch
                                                                                                                {
                                                                                                                    $Message = "Error while performing role assigment $($IAMTemplate.Role) on resource group $ResourceGroupName in subscription $SubcriptionID."
                                                                                                                    $Message                                                                                                    } 
                                                                                                                }
                                                                                                            Else
                                                                                                            {
                                                                                                                $message = "$($IAMTemplate.Role) role does NOT exists in subscription $subscriptionID."
                                                                                                                $Message
                                                                                                            }    
                                                                                                        }
                                                                                                        Else
                                                                                                        {
                                                                                                            $message = "Role name missing in Azure table."
                                                                                                            $Message
                                                                                                        }
                                                                                                    }
                                                                                                    Else
                                                                                                    {
                                                                                                        $Message = "Unable to resolve Azure AD Group $($IAMTemplate.AzureADGroup)."
                                                                                                        $Message
                                                                                                    }
                                                                                                }
                                                                                                Else
                                                                                                {
                                                                                                    $Message = "AzureADGroup name missing in Azure Table."
                                                                                                    $Message
                                                                                                }
                                                                                            }                                                                                 
                                                                                        }
                                                                                        Else
                                                                                        {
                                                                                            $message = "No IAM role template to apply for environnment $AuthorizedEnvironment in subscription $SubscriptionID."
                                                                                            $message
                                                                                        }
                                                                                        #
                                                                                        # Processing PolicyDefinition
                                                                                        #
                                                                                        $PolicyAssignmentTableName = $env:AuthorizationModulePolicyAssignmentTableName
                                                                                        $PolicyAssignmentTable = Get-AzureStorageTable -Name $PolicyAssignmentTableName -Context $context
                                                                                        [string]$Policyfilter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$SubscriptionID)
                                                                                        [string]$Policyfilter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("Environment",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,$AuthorizedEnvironment.toupper())
                                                                                        [string]$PolicyfinalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($Policyfilter1,"and",$Policyfilter2)
                                                                                        $SearchPolicyAssignment = Get-AzureStorageTableRowByCustomFilter -Table $PolicyAssignmentTable -customFilter $PolicyfinalFilter
                                                                                        If ($SearchPolicyAssignment.count -ne 0)
                                                                                        {
                                                                                            $message = "$($SearchPolicyAssignment.count) policie(s) to assign to newly created resource group."
                                                                                            $message
                                                                                            ForEach($PolicyAssignment in $SearchPolicyAssignment)
                                                                                            {
                                                                                                $message = "Processing Policy assignment $($PolicyAssignment.PolicyDefinition)."
                                                                                                $message
                                                                                                #
                                                                                                # Check if PolicyDefinition exists in subscription
                                                                                                #
                                                                                                If (($PolicyAssignment.PolicyDefinition -ne $null) -and ($PolicyAssignment.PolicyName -Ne $Null))
                                                                                                {
                                                                                                    #
                                                                                                    # Azure Policy Definition parameter exists in azure table
                                                                                                    #
                                                                                                    $message = "Azure Policy Definition $($PolicyAssignment.PolicyDefinition) found in azure table."
                                                                                                    $message
                                                                                                    $PolicyDefinition = Get-AzureRmPolicyDefinition | Where {$_.Name -eq $($PolicyAssignment.PolicyDefinition)}
                                                                                                    If ($PolicyDefinition -ne $null)
                                                                                                    {
                                                                                                        $message = "Policy Definition $($PolicyAssignment.PolicyDefinition) exists in subscription $SubscriptionID."
                                                                                                        $message
                                                                                                        $PolicyAssignment.ParameterName
                                                                                                        If ([string]::IsNullOrEmpty($PolicyAssignment.ParameterName))
                                                                                                        {
                                                                                                            #
                                                                                                            # No parameter required for policy assignment
                                                                                                            #
                                                                                                            New-AzureRMPolicyAssignment -Name $($PolicyAssignment.PolicyName)  -Scope $newrg.ResourceId -PolicyDefinition $PolicyDefinition 
                                                                                                        }
                                                                                                        Else
                                                                                                        {
                                                                                                            #
                                                                                                            # Parameter required for Policy Assignment
                                                                                                            #
                                                                                                            "to be continuer ici"
                                                                                                            $parameters = New-Object System.Collections.ArrayList
                                                                                                            $parameters = @{"$PolicyAssignment.ParameterName"=($PolicyAssignment.Parametervalue)}
                                                                                                            # $ResourceGroupTags.Add(@{ Name=$EnvironnementTagname; Value=$AuthorizedEnvironment})
                                                                                                            $parameters
                                                                                                            New-AzureRMPolicyAssignment -Name $($PolicyAssignment.PolicyName)  -Scope $newrg.ResourceId -PolicyDefinition $PolicyDefinition -PolicyParameterObject $parameters
                                                                                                        }
                                                                                                        # de la lecture : http://marcvaneijk.com/2016/03/22/policies.html
                                                                                                        # terminé (sauf si on positionne des locks)
                                                                                                    }
                                                                                                    Else
                                                                                                    {
                                                                                                        $message = "Policy Definition $($PolicyAssignment.PolicyDefinition) does not exists in subscription $SubscriptionID."
                                                                                                        $message
                                                                                                    }
                                                                                                }
                                                                                                Else
                                                                                                {
                                                                                                    $message = "Missing Azure Policy Definition in Azure table."
                                                                                                    $message
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        Else
                                                                                        {
                                                                                            $message = "No Policy assignment found for environment $($AuthorizedEnvironment.toupper()) in subscription $subscriptionID."
                                                                                            $message
                                                                                        }
                                                                                        #
                                                                                        # Return Message
                                                                                        #
                                                                                        $Message = "OK"
                                                                                        $json = $Message |ConvertTo-Json
                                                                                        Out-File -Encoding Ascii -FilePath $res -inputObject $json
                                                                                    }
                                                                                }
                                                                                Catch
                                                                                {
                                                                                    $message = "Error while creating the requested resource group."
                                                                                    $message
                                                                                    #
                                                                                    # Deleting reqource group
                                                                                    #
                                                                                }
                                                                                Finally
                                                                                {
                                                                                    # intégrer ici la suppression du groupe de ressources
                                                                                }
                                                                            }
                                                                            Else
                                                                            {
                                                                                $Message = "Azure region $selectedRegion is not available in subscription $SubscriptionID."
                                                                                $Message
                                                                            }
                                                                        }
                                                                        else
                                                                        { 
                                                                            $message = "$selectedRegion is not allowed for user $account in subscription $SubscriptionID."
                                                                            $message 
                                                                        }                  
                                                                    }                                       
                                                                }
                                                                Else
                                                                {
                                                                    $message = "Requested resource Group $ResourceGroupName already exists in subscription $SubscriptionID."
                                                                    $message
                                                                }
                                                            }
                                                            Else
                                                            {
                                                                $message = "Unable to login to Azure subscription $SubscriptionID with Azure Function Managed Identity."
                                                                $message
                                                            }
                                                        }
                                                        Catch
                                                        {
                                                            #
                                                            # TODO : Améliorer l'analyse de la trace
                                                            #
                                                            $message = $_.Exception.Message
                                                            $message
                                                        }
                                                    }
                                                    Else
                                                    {
                                                        $Message = "Missing credentials to access subscription $SubscriptionID."
                                                        $Message
                                                    }
                                                }
                                                Catch
                                                {
                                                    #
                                                    # TODO : Améliorer l'analyse de la trace
                                                    #
                                                    $Message = "Unable to get extract secrets from Keyvault for subscription $SubscriptionID."
                                                    $Message
                                                    $message = $_.Exception.Message
                                                    $message
                                                }
                                            }
                                            Else
                                            {
                                                $message = "Azure Function is not able to Authenticate against Azure."
                                                $message
                                            }
                                        }
                                        Else
                                        {
                                            $Message = "User $Account is not allowed to use cost center $AuthorizedCostCenter."
                                            $Message
                                        }
                                    }
                                    else
                                    {
                                        $message = "Unable to get default Cost center for user $account in subscription $subscriptionid."
                                        $message
                                    }
                                }
                                Else
                                {
                                    $message = "User $Account is not authorized for environement $AuthorizedEnvironment"
                                    $message
                                }
                            }
                            Else
                            {
                                $message = "Authorized environment list is empty. $account is not allowed to provision new resource groups."
                                Out-File -Encoding Ascii -FilePath $res -inputObject $message
                            }
                        }
                        Else
                        {
                            $Message = "User $Account is not authorized to use the service on subscription ID $SubscriptionID"
                            Out-File -Encoding Ascii -FilePath $res -inputObject $message
                        }
                    }
                    Else
                    {
                        $message = "La souscription ou l'utilisateur ne sont pas référencés dans la table."
                        Out-File -Encoding Ascii -FilePath $res -inputObject $message
                    }
                    # Recherche pour l'environnement sélectionné les Policies à utiliser
                    # Support for Devtest scenario
                }
                Else
                {
                    $message = "Unable to get token from Valet-Key."
                    $message
                }
            }
            Else
            {
                $message = "SubscriptionID GUID format is not valid."
                $Message
            }
        }
        Else
        {
            $Message = "Region parameter is missing."
            $Message
        }
}
Else
{
    $message = "Resource group name is empty."
    $message

}


}
Else
{
    Out-File -Encoding Ascii -FilePath $res -inputObject "Unauthenticated."
}


