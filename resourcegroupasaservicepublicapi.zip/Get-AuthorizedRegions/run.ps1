# Pour une souscription Azure donnée
#
# Version 1.0
#
#
# POST method: $req
$Message = "Initializing Get-AuthorizedRegions API call."
$Message
$requestBody = Get-Content $req -Raw | ConvertFrom-Json
$SubscriptionID = $requestBody.SubscriptionID
$KeyValetUrl = $env:AuthorizationModuleReadKeyvaletURL
$result = Get-Variable -name REQ_HEADERS_X-MS-CLIENT-PRINCIPAL-NAME -ErrorAction SilentlyContinue
if ($result.name -ne $null) 
{
    #
    # Check subscriptionID Format
    #
    If ($SubscriptionID -match("^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$") -eq $True)
    {
        #
        # User Authentication accepted by Active Directory
        #
        $Token = Invoke-RestMethod -Uri $KeyValetUrl -Method POST -ContentType 'application/json'  
        If ($Token -ne $Null)
        {
            #
            # Create security context to Access Azure storage table
            #
            $Message = "Got Key from Valet-Get." 
            $Message
            $storageAccountName = $env:AuthorizationModuleStorageAccountName
            $AuthorizedCallerTableName = $env:AuthorizationModuleAuthorizeTableName
            $context = New-AzureStorageContext -StorageAccountName $storageAccountName -SasToken $Token
            $AuthorizedCallerTable = Get-AzureStorageTable -Name $AuthorizedCallerTableName -Context $context    
            #
            # Filter for subscriptionID & User
            #
            [string]$filter1 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("PartitionKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal, $SubscriptionID)
            [string]$filter2 = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::GenerateFilterCondition("RowKey",[Microsoft.WindowsAzure.Storage.Table.QueryComparisons]::Equal,($($result.value)).tolower())
            [string]$finalFilter = [Microsoft.WindowsAzure.Storage.Table.TableQuery]::CombineFilters($filter1,"and",$filter2)
            $searchsubscription = Get-AzureStorageTableRowByCustomFilter -table $AuthorizedCallerTable -customFilter $finalFilter
            $FoundSubscription = $False
            If ($SearchSubscription -ne $Null)
            {
                $Message = "Found searched row in AuthorizedCallers table."     
                $Message
                ForEach($subscription in $SearchSubscription)
                {
                    If ($subscription.Authorized -eq $True)
                    {
                        $Message = "Subscription is authorized for user $(($result.value).tolower())."
                        $Message
                        $FoundSubscription = $True
                    }
                }
            }
            If ($FoundSubscription -eq $True)
            {
                If (($subscription.AuthorizedRegions) -ne $Null)
                {
                    $json = ($subscription.AuthorizedRegions) |ConvertTo-Json
                    Out-File -Encoding Ascii -FilePath $res -inputObject $json -NoNewline
                }
                Else
                {
                    Out-File -Encoding Ascii -FilePath $res -inputObject "NONE" -NoNewline
                }
            }
            Else
            {
                $Message = "Subscription $SubscriptionID is not Authorized for user $(($result.value).tolower())." 
                $Message
                Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
            }
        }
        Else
        {
            $Message = "Unable to get token from Valet-Key."
            $Message
            Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline 
        }
    }
    Else
    {
        $Message = "Invalid SubscriptionID." 
        $Message
        Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
    }
}
else
{
    $Message = "Unauthenticated Access." 
    $Message
    Out-File -Encoding Ascii -FilePath $res -inputObject $message -NoNewline
}